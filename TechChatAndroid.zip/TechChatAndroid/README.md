# TechChat — Android (Kotlin + Jetpack Compose)

Native Android port of your TechChat HTML app. Same look (dark navy/blue theme, gradient logo),
same features: multiple chats in a sidebar, new chat, delete chat, model switch between
"TechChat 2.0" (Groq/Llama) and "TechChat 1.2" (Gemini), splash screen, welcome suggestions.

## How to open

1. Install **Android Studio** (Koala or newer).
2. Open this folder (`TechChatAndroid`) as a project.
3. Let Gradle sync (it will download the wrapper automatically).
4. Run on an emulator or your phone.

## API keys

Your keys were hardcoded in the HTML file — that's not safe to ship in an app others might
install, so this version asks for them once in **Settings** (tap the gear icon in the sidebar)
and stores them locally on the device only (`SharedPreferences`). They're never in source code.

- Groq key → powers "TechChat 2.0"
- Gemini key → powers "TechChat 1.2"

## What's included

- `ChatViewModel.kt` — chat state, persistence, sending messages
- `data/AiApi.kt` — Groq + Gemini network calls (OkHttp)
- `data/ChatRepository.kt` — save/load chats as JSON in SharedPreferences (like localStorage)
- `ui/ChatScreen.kt` — sidebar, message bubbles, input bar, model dropdown
- `ui/SplashScreen.kt` — animated intro screen
- `ui/SettingsScreen.kt` — enter/update API keys

## Not yet ported (can add on request)

- File/image attachments
- Sound effects on send/receive
- Typing animation (currently shows a "..." indicator, then the full reply at once)
