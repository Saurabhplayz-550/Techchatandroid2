package com.techchat.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class ChatRepository(context: Context) {
    private val prefs = context.getSharedPreferences("techchat_prefs", Context.MODE_PRIVATE)

    fun loadChats(): MutableList<ChatSession> {
        val raw = prefs.getString("techchat_chats", null) ?: return mutableListOf()
        val arr = JSONArray(raw)
        val list = mutableListOf<ChatSession>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val session = ChatSession(
                id = o.getString("id"),
                name = o.getString("name"),
                created = o.optLong("created", System.currentTimeMillis())
            )
            val msgsArr = o.optJSONArray("msgs")
            if (msgsArr != null) {
                for (j in 0 until msgsArr.length()) {
                    val m = msgsArr.getJSONObject(j)
                    val filesArr = m.optJSONArray("fileNames")
                    val files = mutableListOf<String>()
                    if (filesArr != null) {
                        for (k in 0 until filesArr.length()) files.add(filesArr.getString(k))
                    }
                    session.msgs.add(ChatMessage(m.getString("role"), m.getString("text"), files))
                }
            }
            list.add(session)
        }
        return list
    }

    fun saveChats(chats: List<ChatSession>) {
        val arr = JSONArray()
        chats.forEach { c ->
            val o = JSONObject()
            o.put("id", c.id)
            o.put("name", c.name)
            o.put("created", c.created)
            val msgsArr = JSONArray()
            c.msgs.forEach { m ->
                val mo = JSONObject()
                mo.put("role", m.role)
                mo.put("text", m.text)
                mo.put("fileNames", JSONArray(m.fileNames))
                msgsArr.put(mo)
            }
            o.put("msgs", msgsArr)
            arr.put(o)
        }
        prefs.edit().putString("techchat_chats", arr.toString()).apply()
    }

    fun getGroqKey(): String = prefs.getString("groq_api_key", null)?.takeIf { it.isNotBlank() } ?: DEFAULT_GROQ_KEY
    fun setGroqKey(key: String) { prefs.edit().putString("groq_api_key", key).apply() }

    fun getGeminiKey(): String = prefs.getString("gemini_api_key", null)?.takeIf { it.isNotBlank() } ?: DEFAULT_GEMINI_KEY
    fun setGeminiKey(key: String) { prefs.edit().putString("gemini_api_key", key).apply() }

    companion object {
        // Website wali hi keys — user ko manually settings me dalne ki zarurat nahi.
        // Agar user Settings me apni khud ki key daal deta hai, wahi use hogi (upar wale logic me).
        private const val DEFAULT_GROQ_KEY = "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"
        private const val DEFAULT_GEMINI_KEY = "AQ.Ab8RN6Imc48HeHFwcVUvvimE0U2nw29f7Pd5QexXhlfGwkQW3w"
    }

    fun getModel(): String = prefs.getString("techchat_model", AiModel.GROQ.name) ?: AiModel.GROQ.name
    fun setModel(model: String) { prefs.edit().putString("techchat_model", model).apply() }
}
