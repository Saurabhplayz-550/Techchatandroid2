package com.techchat.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.techchat.app.ui.ChatScreen
import com.techchat.app.ui.SettingsScreen
import com.techchat.app.ui.SplashScreen
import com.techchat.app.ui.theme.BgDeep
import com.techchat.app.ui.theme.TechChatTheme

class MainActivity : ComponentActivity() {
    private val vm: ChatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TechChatTheme {
                Surface(modifier = Modifier.fillMaxSize().background(BgDeep)) {
                    var screen by remember { mutableStateOf("splash") }
                    when (screen) {
                        "splash" -> SplashScreen(onFinished = { screen = "chat" })
                        "settings" -> SettingsScreen(vm = vm, onBack = { screen = "chat" })
                        else -> ChatScreen(vm = vm, onOpenSettings = { screen = "settings" })
                    }
                }
            }
        }
    }
}
