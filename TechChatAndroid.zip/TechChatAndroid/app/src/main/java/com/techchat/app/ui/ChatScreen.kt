package com.techchat.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.techchat.app.ChatViewModel
import com.techchat.app.data.AiModel
import com.techchat.app.data.ChatSession
import com.techchat.app.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(vm: ChatViewModel, onOpenSettings: () -> Unit) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Open)
    val scope = rememberCoroutineScope()
    val chats = vm.chats.value
    val activeId = vm.activeChatId.value

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = BgSidebar) {
                SidebarContent(
                    vm = vm,
                    chats = chats,
                    activeId = activeId,
                    onSelect = { id ->
                        vm.loadChat(id)
                        scope.launch { drawerState.close() }
                    },
                    onNewChat = {
                        vm.newChat()
                        scope.launch { drawerState.close() }
                    },
                    onDelete = { vm.deleteChat(it) },
                    onSettings = onOpenSettings
                )
            }
        }
    ) {
        Scaffold(
            containerColor = BgDeep,
            topBar = {
                ChatTopBar(
                    vm = vm,
                    onMenuClick = { scope.launch { drawerState.open() } }
                )
            },
            bottomBar = {
                InputBar(vm = vm, onSend = { vm.sendMessage(it) }, enabled = !vm.isTyping.value)
            }
        ) { padding ->
            Box(modifier = Modifier.padding(padding).fillMaxSize()) {
                val chat = vm.activeChat()
                if (chat == null || chat.msgs.isEmpty()) {
                    WelcomeContent(onSuggestion = { vm.sendMessage(it) })
                } else {
                    MessageList(chat = chat, isTyping = vm.isTyping.value, streamingText = vm.streamingText.value)
                }
            }
        }
    }
}

@Composable
private fun SidebarContent(
    vm: ChatViewModel,
    chats: List<ChatSession>,
    activeId: String?,
    onSelect: (String) -> Unit,
    onNewChat: () -> Unit,
    onDelete: (String) -> Unit,
    onSettings: () -> Unit
) {
    Column(modifier = Modifier.fillMaxHeight().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(Brush.linearGradient(listOf(Color(0xFF0A1E3D), Accent)), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Chat, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
            }
            Column {
                Text("TechChat", color = TextPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                Text("AI POWERED", color = Accent, fontSize = 10.sp)
            }
        }
        Spacer(Modifier.height(20.dp))
        OutlinedButton(
            onClick = onNewChat,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Accent)
        ) {
            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(8.dp))
            Text("New Chat")
        }
        Spacer(Modifier.height(20.dp))
        Text("CONVERSATIONS", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        LazyColumn(modifier = Modifier.weight(1f)) {
            itemsIndexed(chats) { _, chat ->
                ChatListItem(
                    chat = chat,
                    active = chat.id == activeId,
                    onClick = { onSelect(chat.id) },
                    onDelete = { onDelete(chat.id) }
                )
            }
        }
        Divider(color = Color.White.copy(alpha = 0.05f))
        Spacer(Modifier.height(8.dp))
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth().clickable { onSettings() }.padding(vertical = 8.dp)
        ) {
            Icon(Icons.Filled.Settings, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(8.dp))
            Text("Settings", color = TextSecondary, fontSize = 13.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(8.dp).background(OnlineGreen, CircleShape))
            Spacer(Modifier.width(8.dp))
            Text("TechChat v3.0 · Online", color = TextSecondary, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ChatListItem(chat: ChatSession, active: Boolean, onClick: () -> Unit, onDelete: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(if (active) Accent.copy(alpha = 0.14f) else Color.Transparent)
            .clickable { onClick() }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.ChatBubbleOutline, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(14.dp))
        Spacer(Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(chat.name, color = TextPrimary, fontSize = 13.sp, maxLines = 1)
            Text("${chat.msgs.size} messages", color = TextMuted, fontSize = 11.sp)
        }
        IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
            Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete", tint = TextMuted, modifier = Modifier.size(14.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChatTopBar(vm: ChatViewModel, onMenuClick: () -> Unit) {
    var dropdownOpen by remember { mutableStateOf(false) }
    TopAppBar(
        title = { Text("TechChat", fontWeight = FontWeight.Bold) },
        navigationIcon = {
            IconButton(onClick = onMenuClick) {
                Icon(Icons.Filled.Menu, contentDescription = "Menu", tint = TextSecondary)
            }
        },
        actions = {
            Box {
                AssistChip(
                    onClick = { dropdownOpen = true },
                    label = { Text(vm.currentModel.value.label, fontSize = 11.sp) },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = Accent.copy(alpha = 0.08f),
                        labelColor = Accent
                    )
                )
                DropdownMenu(expanded = dropdownOpen, onDismissRequest = { dropdownOpen = false }) {
                    AiModel.values().forEach { model ->
                        DropdownMenuItem(
                            text = { Text(model.label) },
                            onClick = {
                                vm.selectModel(model)
                                dropdownOpen = false
                            }
                        )
                    }
                }
            }
            Spacer(Modifier.width(8.dp))
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = BgDeep, titleContentColor = TextPrimary)
    )
}

@Composable
private fun WelcomeContent(onSuggestion: (String) -> Unit) {
    val suggestions = listOf(
        "Write advanced code 💻",
        "Analyze a concept 🖼️",
        "Explain a concept 🧠",
        "Debug my error 🔧"
    )
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(76.dp)
                .background(Brush.linearGradient(listOf(Color(0xFF0A1E3D), Accent)), RoundedCornerShape(24.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Chat, contentDescription = null, tint = Color.White, modifier = Modifier.size(36.dp))
        }
        Spacer(Modifier.height(20.dp))
        Text("Welcome to TechChat", color = TextPrimary, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Your intelligent AI assistant. Ask me anything — code, ideas, analysis, and more.",
            color = TextSecondary,
            fontSize = 14.sp,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        suggestions.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { s ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(BgCard)
                            .clickable { onSuggestion(s.replace(Regex("[^\\p{ASCII}]"), "").trim()) }
                            .padding(14.dp)
                    ) {
                        Text(s, color = TextSecondary, fontSize = 13.sp)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
private fun MessageList(chat: ChatSession, isTyping: Boolean, streamingText: String?) {
    val listState = rememberLazyListState()
    LaunchedEffect(chat.msgs.size, isTyping, streamingText) {
        if (chat.msgs.isNotEmpty() || isTyping) {
            val target = chat.msgs.size + if (isTyping) 1 else 0
            if (target > 0) listState.animateScrollToItem(target - 1)
        }
    }
    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        items(chat.msgs) { msg ->
            MessageBubble(role = msg.role, text = msg.text, fileNames = msg.fileNames)
        }
        if (isTyping) {
            item {
                if (streamingText.isNullOrEmpty()) {
                    TypingBubble()
                } else {
                    MessageBubble(role = "ai", text = streamingText, fileNames = emptyList())
                }
            }
        }
    }
}

@Composable
private fun MessageBubble(role: String, text: String, fileNames: List<String>) {
    val isUser = role == "user"
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 280.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(if (isUser) BgMsgUser else BgMsgAi)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            fileNames.forEach { name ->
                Row(
                    modifier = Modifier
                        .padding(bottom = 6.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Accent.copy(alpha = 0.1f))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.InsertDriveFile, contentDescription = null, tint = Accent, modifier = Modifier.size(13.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(name, color = Accent, fontSize = 12.sp, maxLines = 1)
                }
            }
            if (text.isNotBlank()) {
                Text(text, color = TextPrimary, fontSize = 14.sp, lineHeight = 20.sp)
            }
        }
    }
}

@Composable
private fun TypingBubble() {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(BgMsgAi)
                .padding(horizontal = 18.dp, vertical = 14.dp)
        ) {
            Text("● ● ●", color = Accent, fontSize = 12.sp)
        }
    }
}

@Composable
private fun InputBar(vm: ChatViewModel, onSend: (String) -> Unit, enabled: Boolean) {
    var text by remember { mutableStateOf("") }
    val context = androidx.compose.ui.platform.LocalContext.current
    val pendingFiles = vm.pendingFiles.value

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        uris.forEach { uri ->
            val name = queryFileName(context, uri) ?: "file"
            vm.addPendingFile(name)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(BgDeep)
            .padding(12.dp)
    ) {
        if (pendingFiles.isNotEmpty()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                pendingFiles.forEachIndexed { index, name ->
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(BgInput)
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.InsertDriveFile, contentDescription = null, tint = Accent, modifier = Modifier.size(13.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(
                            name.take(15) + if (name.length > 15) "…" else "",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                        Spacer(Modifier.width(6.dp))
                        Icon(
                            Icons.Filled.Close,
                            contentDescription = "Remove",
                            tint = TextMuted,
                            modifier = Modifier
                                .size(13.dp)
                                .clickable { vm.removePendingFile(index) }
                        )
                    }
                }
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(BgInput)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { filePicker.launch("*/*") }) {
                Icon(Icons.Filled.AttachFile, contentDescription = "Attach", tint = TextSecondary)
            }
            TextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Message TechChat...", color = TextMuted) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                maxLines = 5
            )
            IconButton(
                onClick = {
                    if ((text.isNotBlank() || pendingFiles.isNotEmpty()) && enabled) {
                        onSend(text.trim())
                        text = ""
                    }
                },
                enabled = enabled
            ) {
                Icon(Icons.Filled.Send, contentDescription = "Send", tint = Accent)
            }
        }
        Text(
            "TechChat can make mistakes. Verify important information.",
            color = TextMuted,
            fontSize = 10.sp,
            modifier = Modifier.padding(top = 6.dp, start = 8.dp)
        )
    }
}

private fun queryFileName(context: android.content.Context, uri: android.net.Uri): String? {
    var name: String? = null
    val cursor = context.contentResolver.query(uri, null, null, null, null)
    cursor?.use {
        val nameIndex = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
        if (it.moveToFirst() && nameIndex >= 0) {
            name = it.getString(nameIndex)
        }
    }
    return name ?: uri.lastPathSegment
}

// LazyColumn items() extension needed for List<ChatMessage>
private fun androidx.compose.foundation.lazy.LazyListScope.items(
    list: List<com.techchat.app.data.ChatMessage>,
    itemContent: @Composable (com.techchat.app.data.ChatMessage) -> Unit
) {
    items(list.size) { index -> itemContent(list[index]) }
}
