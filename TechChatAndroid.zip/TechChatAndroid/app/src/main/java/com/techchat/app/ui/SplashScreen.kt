package com.techchat.app.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.techchat.app.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(onFinished: () -> Unit) {
    val infiniteTransition = rememberInfiniteTransition(label = "splash")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(tween(1200), RepeatMode.Reverse),
        label = "pulse"
    )
    var loadProgress by remember { mutableStateOf(0f) }

    LaunchedEffect(Unit) {
        loadProgress = 1f
        delay(2200)
        onFinished()
    }
    val animatedProgress by animateFloatAsState(
        targetValue = loadProgress,
        animationSpec = tween(1600),
        label = "progress"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDeep),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(24.dp)) {
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .scale(pulse)
                    .background(
                        Brush.linearGradient(listOf(Color(0xFF0A1E3D), Color(0xFF1A4A9E), Accent)),
                        RoundedCornerShape(28.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Chat, contentDescription = null, tint = Color.White, modifier = Modifier.size(40.dp))
            }
            Text(
                "TechChat",
                color = TextPrimary,
                fontSize = 40.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Text("Your intelligent AI assistant", color = TextSecondary, fontSize = 14.sp)
            Box(
                modifier = Modifier
                    .width(200.dp)
                    .height(3.dp)
                    .background(Color.White.copy(alpha = 0.06f), RoundedCornerShape(2.dp))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(animatedProgress)
                        .background(Brush.horizontalGradient(listOf(Accent, Accent2)), RoundedCornerShape(2.dp))
                )
            }
        }
    }
}
