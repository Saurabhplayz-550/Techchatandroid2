package com.techchat.app.data

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.sin

class SoundPlayer {
    private val sampleRate = 44100

    private fun tone(freqStart: Double, freqEnd: Double, durationSec: Double, volume: Double): ShortArray {
        val numSamples = (sampleRate * durationSec).toInt()
        val samples = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val progress = i.toDouble() / numSamples
            val freq = freqStart + (freqEnd - freqStart) * progress
            val envelope = Math.exp(-3.0 * progress) // decay like exponentialRampToValueAtTime
            val sample = sin(2.0 * PI * freq * t) * volume * envelope
            samples[i] = (sample * Short.MAX_VALUE).toInt().toShort()
        }
        return samples
    }

    private fun playSamples(samples: ShortArray) {
        try {
            val bufferSize = samples.size * 2
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(sampleRate)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            track.write(samples, 0, samples.size)
            track.play()
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                track.release()
            }, (samples.size.toDouble() / sampleRate * 1000).toLong() + 100)
        } catch (_: Exception) {
            // Ignore audio failures silently, non-critical
        }
    }

    fun playSend() {
        playSamples(tone(900.0, 900.0, 0.12, 0.2))
    }

    fun playReceive() {
        playSamples(tone(660.0, 880.0, 0.2, 0.18))
    }

    fun playNewChat() {
        playSamples(tone(440.0, 880.0, 0.25, 0.15))
    }

    fun playClick() {
        playSamples(tone(500.0, 500.0, 0.06, 0.12))
    }

    fun playDelete() {
        playSamples(tone(500.0, 250.0, 0.15, 0.18))
    }
}
