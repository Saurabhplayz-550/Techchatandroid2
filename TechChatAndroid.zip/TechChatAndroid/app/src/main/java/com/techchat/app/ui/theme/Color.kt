package com.techchat.app.ui.theme

import androidx.compose.ui.graphics.Color

val BgDeep = Color(0xFF070B14)
val BgCard = Color(0xFF0D1525)
val BgSidebar = Color(0xFF0A1120)
val BgInput = Color(0xFF111D33)
val BgMsgUser = Color(0xFF1A3A6E)
val BgMsgAi = Color(0xFF0F1E35)
val Accent = Color(0xFF3D8EF8)
val AccentGlow = Color(0x593D8EF8)
val Accent2 = Color(0xFF5EEAD4)
val TextPrimary = Color(0xFFE8EDF5)
val TextSecondary = Color(0xFF6B82A8)
val TextMuted = Color(0xFF3D5070)
val BorderColor = Color(0x263D8EF8)
val OnlineGreen = Color(0xFF22C55E)
val DangerRed = Color(0xFFEF4444)
