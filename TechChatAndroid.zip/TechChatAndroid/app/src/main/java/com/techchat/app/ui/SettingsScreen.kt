package com.techchat.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.techchat.app.ChatViewModel
import com.techchat.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: ChatViewModel, onBack: () -> Unit) {
    var groqKey by remember { mutableStateOf(vm.getGroqKey()) }
    var geminiKey by remember { mutableStateOf(vm.getGeminiKey()) }
    var saved by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = BgDeep,
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BgDeep, titleContentColor = TextPrimary)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(20.dp)
                .fillMaxSize()
        ) {
            Text("Groq API Key (TechChat 2.0)", color = TextSecondary, style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = groqKey,
                onValueChange = { groqKey = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("gsk_...") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
            )
            Spacer(Modifier.height(20.dp))
            Text("Gemini API Key (TechChat 1.2)", color = TextSecondary, style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = geminiKey,
                onValueChange = { geminiKey = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("AIza...") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
            )
            Spacer(Modifier.height(24.dp))
            Button(
                onClick = {
                    vm.setGroqKey(groqKey.trim())
                    vm.setGeminiKey(geminiKey.trim())
                    saved = true
                },
                colors = ButtonDefaults.buttonColors(containerColor = Accent)
            ) {
                Text("Save Keys")
            }
            if (saved) {
                Spacer(Modifier.height(12.dp))
                Text("Saved ✓", color = Accent2)
            }
            Spacer(Modifier.height(24.dp))
            Text(
                "App already comes with working keys built-in. Change them here only if you want to use your own.",
                color = TextMuted,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
