package com.techchat.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TechChatColors = darkColorScheme(
    background = BgDeep,
    surface = BgCard,
    primary = Accent,
    secondary = Accent2,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    error = DangerRed
)

@Composable
fun TechChatTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = TechChatColors,
        typography = MaterialTheme.typography,
        content = content
    )
}
