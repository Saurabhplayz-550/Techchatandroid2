package com.techchat.app

import android.app.Application
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.techchat.app.data.AiApi
import com.techchat.app.data.AiModel
import com.techchat.app.data.ChatMessage
import com.techchat.app.data.ChatRepository
import com.techchat.app.data.ChatSession
import com.techchat.app.data.SoundPlayer
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = ChatRepository(app)
    private val api = AiApi()
    private val sounds = SoundPlayer()

    val chats = mutableStateOf(repo.loadChats())
    val activeChatId = mutableStateOf<String?>(null)
    val isTyping = mutableStateOf(false)
    val currentModel = mutableStateOf(
        if (repo.getModel() == AiModel.GEMINI.name) AiModel.GEMINI else AiModel.GROQ
    )
    // Text revealed so far during the word-by-word typing animation of the AI reply
    val streamingText = mutableStateOf<String?>(null)
    val sidebarOpen = mutableStateOf(true)
    val pendingFiles = mutableStateOf<List<String>>(emptyList())

    init {
        if (chats.value.isEmpty()) newChat() else activeChatId.value = chats.value.first().id
    }

    fun activeChat(): ChatSession? = chats.value.find { it.id == activeChatId.value }

    fun newChat() {
        sounds.playNewChat()
        val id = "chat_" + System.currentTimeMillis()
        val session = ChatSession(id = id, name = "New Chat")
        chats.value = (listOf(session) + chats.value).toMutableList()
        activeChatId.value = id
        persist()
    }

    fun loadChat(id: String) {
        sounds.playClick()
        activeChatId.value = id
    }

    fun deleteChat(id: String) {
        sounds.playDelete()
        val updated = chats.value.filterNot { it.id == id }.toMutableList()
        chats.value = updated
        if (activeChatId.value == id) {
            activeChatId.value = updated.firstOrNull()?.id
            if (updated.isEmpty()) newChat()
        }
        persist()
    }

    fun selectModel(model: AiModel) {
        sounds.playClick()
        currentModel.value = model
        repo.setModel(model.name)
    }

    fun getGroqKey() = repo.getGroqKey()
    fun setGroqKey(k: String) = repo.setGroqKey(k)
    fun getGeminiKey() = repo.getGeminiKey()
    fun setGeminiKey(k: String) = repo.setGeminiKey(k)

    fun addPendingFile(name: String) {
        pendingFiles.value = pendingFiles.value + name
    }

    fun removePendingFile(index: Int) {
        pendingFiles.value = pendingFiles.value.filterIndexed { i, _ -> i != index }
    }

    fun sendMessage(text: String) {
        val chat = activeChat() ?: return
        val files = pendingFiles.value
        if (text.isBlank() && files.isEmpty()) return
        if (isTyping.value) return

        sounds.playSend()

        if (chat.msgs.isEmpty()) {
            chat.name = (text.ifBlank { files.firstOrNull() ?: "Chat" }).take(36)
        }
        chat.msgs.add(ChatMessage("user", text, files))
        pendingFiles.value = emptyList()
        persist()
        forceRefresh()

        isTyping.value = true
        streamingText.value = null

        viewModelScope.launch {
            val history = chat.msgs.dropLast(1)
            var messageForModel = text
            if (files.isNotEmpty()) {
                messageForModel += (if (text.isNotBlank()) "\n" else "") + "[Attached file(s): ${files.joinToString(", ")}]"
            }

            val reply = try {
                if (currentModel.value == AiModel.GROQ) {
                    api.callGroq(getGroqKey(), history, messageForModel)
                } else {
                    api.callGemini(getGeminiKey(), history, messageForModel)
                }
            } catch (e: Exception) {
                "❌ Connection Error: ${e.message}"
            }

            sounds.playReceive()
            typeOutReply(reply)

            chat.msgs.add(ChatMessage("ai", reply))
            isTyping.value = false
            streamingText.value = null
            persist()
            forceRefresh()
        }
    }

    // Reveals the reply word-by-word, mirroring the typing animation in the HTML app
    private suspend fun typeOutReply(fullText: String) {
        val words = fullText.split(" ")
        val builder = StringBuilder()
        for ((i, word) in words.withIndex()) {
            if (i > 0) builder.append(" ")
            builder.append(word)
            streamingText.value = builder.toString()
            delay(24)
        }
    }

    private fun forceRefresh() {
        chats.value = chats.value.toMutableList()
    }

    private fun persist() {
        repo.saveChats(chats.value)
    }
}
