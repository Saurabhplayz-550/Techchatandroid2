package com.techchat.app.data

data class ChatMessage(
    val role: String, // "user" or "ai"
    val text: String,
    val fileNames: List<String> = emptyList()
)

data class ChatSession(
    val id: String,
    var name: String,
    val msgs: MutableList<ChatMessage> = mutableListOf(),
    val created: Long = System.currentTimeMillis()
)

enum class AiModel(val label: String) {
    GROQ("TechChat 2.0"),
    GEMINI("TechChat 1.2")
}

const val SYSTEM_CONTEXT = """You are TechChat AI, a helpful and intelligent assistant.

Default language: Respond in English by default. If the user writes in Hindi, respond in Hindi. Otherwise, match the user's language.

Only mention who built you if the user directly asks who made/built/created you. In that case say you were built by Saurabh Kumar and Tejas Kumar. Never volunteer this unprompted, and never mention any underlying model provider."""
