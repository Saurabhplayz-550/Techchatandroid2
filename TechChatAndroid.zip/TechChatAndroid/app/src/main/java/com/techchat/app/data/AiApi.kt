package com.techchat.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class AiApi {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()
    private val jsonMedia = "application/json; charset=utf-8".toMediaType()

    suspend fun callGroq(apiKey: String, history: List<ChatMessage>, newText: String): String =
        withContext(Dispatchers.IO) {
            if (apiKey.isBlank()) return@withContext "⚠️ Groq API key missing. Add it in Settings first."

            val messages = JSONArray()
            messages.put(JSONObject().put("role", "system").put("content", SYSTEM_CONTEXT))
            history.forEach { m ->
                messages.put(
                    JSONObject()
                        .put("role", if (m.role == "ai") "assistant" else "user")
                        .put("content", m.text)
                )
            }
            messages.put(JSONObject().put("role", "user").put("content", newText))

            val body = JSONObject()
                .put("model", "llama-3.3-70b-versatile")
                .put("messages", messages)
                .put("temperature", 0.7)

            val request = Request.Builder()
                .url("https://api.groq.com/openai/v1/chat/completions")
                .addHeader("Authorization", "Bearer $apiKey")
                .addHeader("Content-Type", "application/json")
                .post(body.toString().toRequestBody(jsonMedia))
                .build()

            client.newCall(request).execute().use { resp ->
                val respBody = resp.body?.string() ?: return@withContext "❌ Empty response"
                if (!resp.isSuccessful) return@withContext "❌ Connection Error: ${resp.code}"
                val json = JSONObject(respBody)
                json.optJSONArray("choices")
                    ?.optJSONObject(0)
                    ?.optJSONObject("message")
                    ?.optString("content")
                    ?: "⚠️ Koi jawab nahi mila. Dobara try karo."
            }
        }

    suspend fun callGemini(apiKey: String, history: List<ChatMessage>, newText: String): String =
        withContext(Dispatchers.IO) {
            if (apiKey.isBlank()) return@withContext "⚠️ Gemini API key missing. Add it in Settings first."

            val contents = JSONArray()
            contents.put(
                JSONObject().put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", SYSTEM_CONTEXT)))
            )
            contents.put(
                JSONObject().put("role", "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", "Understood, I will follow these instructions.")))
            )
            history.forEach { m ->
                contents.put(
                    JSONObject()
                        .put("role", if (m.role == "ai") "model" else "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", m.text)))
                )
            }
            contents.put(
                JSONObject().put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", newText)))
            )

            val body = JSONObject().put("contents", contents)
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"

            val request = Request.Builder()
                .url(url)
                .addHeader("Content-Type", "application/json")
                .post(body.toString().toRequestBody(jsonMedia))
                .build()

            client.newCall(request).execute().use { resp ->
                val respBody = resp.body?.string() ?: return@withContext "❌ Empty response"
                if (!resp.isSuccessful) return@withContext "❌ Connection Error: ${resp.code}"
                val json = JSONObject(respBody)
                json.optJSONArray("candidates")
                    ?.optJSONObject(0)
                    ?.optJSONObject("content")
                    ?.optJSONArray("parts")
                    ?.optJSONObject(0)
                    ?.optString("text")
                    ?: "⚠️ Koi jawab nahi mila. Dobara try karo."
            }
        }
}
